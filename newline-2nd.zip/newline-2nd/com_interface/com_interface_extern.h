#ifndef COM_INTERFACE_EXTERN_H
#define COM_INTERFACE_EXTERN_H

void Pub_MSleep(int micSeconds);	//休眠函数

#endif // COM_INTERFACE_EXTERN_H
